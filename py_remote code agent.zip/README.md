# Remote Code Bridge - Setup Guide

This tool allows you to send code/text from a restricted environment (like a company PC via the web) to your home computer via Google Drive.

## Validation Steps

1.  **Install Dependencies**:
    ```bash
    pip install -r requirements.txt
    ```

2.  **Google Cloud Setup**:
    -   Go to Google Cloud Console.
    -   Create a new project.
    -   Enable **Google Drive API**.
    -   Create a **Service Account** and download the JSON key.
    -   **Important**: Share your target Google Drive folder with the Service Account's email address (found in the JSON).

3.  **Configure Secrets**:
    -   Create a file `.streamlit/secrets.toml` (copy from `.streamlit/secrets.toml.example`).
    -   Fill in `gdrive_folder_id` with the ID of your shared folder.
    -   Fill in `[gcp_service_account]` with the details from your JSON key.

4.  **Run the App**:
    ```bash
    streamlit run app.py
    ```

5.  **Test**:
    -   Open the web interface.
    -   Enter a filename (e.g., `test_bridge`).
    -   Select `.txt`.
    -   Type "Hello from the other side".
    -   Click **Send to Home**.
    -   Check your Google Drive folder.
